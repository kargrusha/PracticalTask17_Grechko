Практическая 17 (работа с картами)

![image](https://github.com/user-attachments/assets/55af2340-b0f8-4d73-868a-7cdea551afe1)
